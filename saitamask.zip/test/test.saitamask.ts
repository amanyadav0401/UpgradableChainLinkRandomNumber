import { SignerWithAddress } from "@nomiclabs/hardhat-ethers/signers";
import { ethers, network } from "hardhat";
import {
  expandTo18Decimals,
  expandTo6Decimals,
} from "./shared/utilities";
import {
  SaitaMask,
  SaitaMask__factory,
  Token,
  Token__factory,
} from "../typechain";
import chai, { expect } from "chai";
describe("Saitamask Testing", () => {
  let owner: SignerWithAddress;
  let signers: SignerWithAddress[];

  let token: Token;
  let staking: SaitaMask;

  beforeEach(async () => {
    signers = await ethers.getSigners();
    owner = await signers[0];

    token = await new Token__factory(owner).deploy();
    staking = await new SaitaMask__factory(owner).deploy(
      token.address
    );

    await staking.connect(owner).setRewardPercent(30, 10);
    await staking.connect(owner).setRewardPercent(60, 20);
    await staking.connect(owner).setRewardPercent(90, 30);

    await token
      .connect(owner)
      .transfer(staking.address, expandTo18Decimals(100000));
    await token
      .connect(owner)
      .transfer(signers[1].address, expandTo18Decimals(1000));
    await token
      .connect(owner)
      .transfer(signers[2].address, expandTo18Decimals(1000));

    await token
      .connect(signers[1])
      .approve(staking.address, expandTo18Decimals(1000));
    await token
      .connect(signers[2])
      .approve(staking.address, expandTo18Decimals(1000));
      await token
      .connect(signers[3])
      .approve(staking.address, expandTo18Decimals(1000));

      await token
      .connect(signers[2])
      .approve(staking.address, expandTo18Decimals(1000));

  });

  it("Stakes the amount", async () => {
    await staking.connect(signers[1]).stake(30, 100);
    await staking.connect(signers[1]).stake(30, 100);
    await staking.connect(signers[1]).stake(30, 100);

    await staking.connect(signers[1]).stake(60, 100);
    await staking.connect(signers[1]).stake(90, 100);
    await staking.connect(signers[1]).stake(30, 100);


    console.log(
      "Amount staked by Signers[1]: " +
        (await staking.stakingTx(signers[1].address))
    );
    console.log(
      "Total balance signers[1]:" +
        (await token.balanceOf(signers[1].address))
    );
    await network.provider.send("evm_increaseTime", [30]);
    await network.provider.send("evm_mine");

    await expect(staking.connect(signers[1])
      .claimReward(4))
      .to.be.revertedWith("Stake period is not over.");
    console.log(
      "Total balance signers[1] after claiming:" +
        (await token.balanceOf(signers[1].address))   
    );
    it.only("claimAllRewards",async()=>{
      await staking.connect(signers[1]).stake(30, 100);
      await staking.connect(signers[1]).stake(30, 100);
      await staking.connect(signers[1]).stake(30, 100);
  
      await staking.connect(signers[1]).stake(60, 100);
      await staking.connect(signers[1]).stake(75, 100);
      await staking.connect(signers[1]).stake(90, 100);
      console.log(
        "Amount staked by Signers[1]: " +
          (await staking.stakingTx(signers[1].address))
      );
      await  (staking.connect(signers[1]).claimAllRewards())
      await network.provider.send("evm_increaseTime", [60]);
      await network.provider.send("evm_mine");
  
    })


  });
});
